Ext.define('App.overrides.LoadMask', {
    override: 'Ext.LoadMask',

    config: {
        message: ''
    }
});
