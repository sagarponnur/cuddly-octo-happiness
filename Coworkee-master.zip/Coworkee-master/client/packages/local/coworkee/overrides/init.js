Ext.namespace('Ext.theme.is')['coworkee'] = true;
Ext.theme.name = 'coworkee';
